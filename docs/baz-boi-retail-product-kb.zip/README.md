# BOI Retail Product Knowledge Base for Baz

**Version:** 1.0  
**Public-site review:** 2026-10-08  
**Catalogue objects:** 61

## Purpose

This pack converts Bank of Ireland's public Irish retail offering into a machine-readable catalogue Baz can use for needs discovery, product explanation, comparison and orchestration.

The JSON is intentionally richer than a flat product list. Each object can contain:

- customer job / purpose;
- best-fit situations;
- features and benefits;
- eligibility;
- constraints and cautions;
- rates/fees snapshots where useful;
- channels;
- advice/underwriting model;
- related products;
- Baz surfacing and clarification guidance;
- freshness classification;
- source URLs.

## Files

- `boi-retail-product-knowledge-base.json` — primary runtime catalogue.
- `boi-retail-product-matrix.csv` — flattened review matrix.
- `boi-retail-product-knowledge-base.schema.json` — lightweight schema.

## Coverage

- **banking**: 9
- **borrowing**: 17
- **insurance**: 3
- **mortgages**: 9
- **payments**: 1
- **protection**: 4
- **retirement**: 6
- **saving**: 9
- **wealth**: 3

## Runtime architecture

```text
Customer context
      ↓
Goal Engine
      ↓
Needs Engine
      ↓
Candidate product IDs
      ↓
Product Knowledge Base
      ↓
Live rates / availability / eligibility service where required
      ↓
Baz explanation
```

## Freshness

The catalogue uses:

- `semi_static`
- `dynamic`
- `expiry_sensitive`
- `requires_internal_live_data`

Stable descriptive facts can live in the catalogue. Live rates, APR/APRC, offers, mortgage pricing, insurance premiums and time-limited schemes should be refreshed before Baz presents them as current.

## Customer language

Prefer:

> “You mentioned X. BOI has an option designed to help with Y. Here’s how it works.”

Avoid:

> “This is definitely the best product for you.”

unless the authorised advice/decision process supports that conclusion.

## Advice-led categories

Investments, pensions and protection are deliberately represented differently from transactional products.

Baz should identify the need, explain the category, gather appropriate pre-advice context, and then hand into the authorised suitability/advice/underwriting journey.

It should not independently choose an investment fund, pension wrapper, protection amount or risk profile.

## Important caveats

- Rate figures in this pack are snapshots only.
- Where BOI's own page states an older effective date for a representative rate, that date is preserved in the product object's pricing metadata.
- `loan.home_energy_upgrade` must be live-checked because the scheme is stated to end **31 December 2026 or earlier if funds are exhausted**.
- `current.young_saver` and `service.premier` should not be actively surfaced until their current eligibility/product rules are internally verified.
